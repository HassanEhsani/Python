print("please enter 2 numbers")
s = input()
i = 0
s1 = ""
for c in s:
    if c!= " ":
     s1 += c
print("she is without gaps = ", s1)
