N = int(input("please enter n:"))
f = 1
for i in range(1, N+1):
    f = f*i
print(N, "! = ", f)
