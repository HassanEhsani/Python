print("please enter the number for count")
n = int(input())
while n > 0:
    print("Hello")
    n -= 1
