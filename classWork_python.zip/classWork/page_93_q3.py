for i in range(100, 999):
    if i % 15 == 11 and i % 11 == 9:
        print(i)
