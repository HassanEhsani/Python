print("please enter the number of week: ")
n = int(input())
if n == 1:
    print("Monday","=>",n)
elif n == 2:
    print("Tuesday","=>",n)
elif n == 3:
    print("Wendsday","=>",n)
elif n == 4:
    print("Thursday","=>",n)
elif n == 5:
    print("Friday","=>",n)
elif n == 6:
    print("Saturday","=>",n)
elif n == 7:
    print("Sunday","=>",n)
else:
    print("your number is wrong!")
